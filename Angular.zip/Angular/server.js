/* 
** JavaScript Document
** File Name: server.js
** Created By : Prashant Jha
** Created On: 1st May 2013
** File path: "/"
*/

/**
 * File that statrs the server and launches index.html as the home page
 */

/*Connect module required to create server*/
var connect = require('connect');

/*Port on which server is running*/
var port=5005;
connect.createServer(
    connect.static(__dirname)
).listen(port);






