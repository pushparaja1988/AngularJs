///**
// * Created by Push on 6/23/15.
// */

myRouting.controller('getAllController',['$http','getAllService','$scope',function($http,getAllService,$scope)
{

    //Working https URL Without Header

    $http.get("https://data.usajobs.gov/api/jobs?series=2210",
        {
            // headers: {"Authorization": "Basic MmNiZmJlY2MtMDU1ZC00MTEzLWEzNTYtY2I0Yjc4NzFlMDVl"} // Custom headers put in.
        })
        .success(function(data, status, headers, config) {
            $scope.employee = data.JobData; // Sets the employee object in $scope
        })
        .error(function(data, status, headers, config) {
            alert("failure");
        });

    //$http.get('https://api.insight.ly/v2.1/Contacts',
    //    {
    //        headers: {"Authorization": "Basic ZWY0OGRhMTctMzVjNi00MGJkLTg5ZTktNTNlYjY0OTZkYzQy"} // Custom headers put in.
    //
    //    })
    //    .success(function(data, status, headers, config) {
    //        console.log(data);
    //        $scope.employee = data; // Sets the employee object in $scope
    //    })
    //    .error(function(data, status, headers, config) {
    //        alert("failure");
    //    });
    //
    //$http.get('https://onecdevintappsproxysrvs.cognizant.com/872/QuickExp_Authentication/Service1.svc/Userauthentication',
    //    {
    //        headers: {"Authorization": "Basic Y3RzXDI5MDM0NTpQdXNoMTIzNDUl"} // Custom headers put in.
    //
    //    })
    //    .success(function(data, status, headers, config) {
    //        console.log(data);
    //        $scope.employee = data; // Sets the employee object in $scope
    //    })
    //    .error(function(data, status, headers, config) {
    //        alert("failure");
    //    });

     // Simple GET request example :

       // getAllService.get('https://api.github.com/users/peterbe/gists').
       // getAllService.get().
       // success(function(data, status, headers, config) {
       //     console.log("Result: "+data);
       //     $scope.name=data;
       //
       // }).
       // error(function(data, status, headers, config) {
       //     console.log("Error: "+data);
       //     // called asynchronously if an error occurs
       //     // or server returns response with an error status.
       // });



    //$scope.data= $http.get('https://api.mongolab.com/api/1/databases/angularjs-intro/collections/users?apiKey=terrPcifZzn01_ImGsFOIZ96SwvSXgN9');
    //console.log($scope.data);
    //server.get().success(function(res)
    //{
    //
    //});

    //getAllService.get('https://api.mongolab.com/api/1/databases/angularjs-intro/collections/users?apiKey=terrPcifZzn01_ImGsFOIZ96SwvSXgN9').then(function(response) {
    //    $scope.result = response;
    //    console.log('Success' +  $scope.result);
    //}, function(error) {
    //    console.log('Failure' + error);
    //});
}]);