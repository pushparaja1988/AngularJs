/**
 * Created by Push on 6/23/15.
 */
var services = angular.module('myRouting.services', []);

services.factory('getAllService', ['$http', function ($http) {
    return {
        get: function () {
            return $http.get(url);
        }
    };
}]);
