var myRouting = angular.module('sampleRouting',['myRouting.services','ngRoute']);

myRouting.config(['$routeProvider',function ($routeProvider) {
	$routeProvider.
	when('/login',{
		templateUrl:'templates/login.html',
		controller:'titleText'
	}).
	when('/success',{
		templateUrl:'templates/formElements.html'
	}).
	when('/jobDetails/:JobSummary',{
		templateUrl:'templates/jobDetails.html',
		controller:"jobDetailsCtrl"
	}).
	otherwise({
		redirectTo:'/login'
	});
}]);

myRouting.controller('titleText',function($scope)
{
	console.log('Welcome');
	$scope.message='Admin Login';
	window.history.forward();
	setTimeout("preventBack()", 0);
	window.onunload=function(){null};
});

myRouting.controller('loginEmptyCheck',['$scope','$location','$window',function($scope,$location,$window){
	$scope.usrname ="admin";
	$scope.passwd="password-1";
	$scope.test=function()
	{

		if($scope.usrname =="admin" && $scope.passwd=="password-1")
		{
			//$window.location.href = 'partials/home.html';
			//$location.absUrl='test.html';
			$location.path('/success');
			//alert($location.path());
			console.log("success");
			//alert("test");
		}
		else
		{
			alert("Invalid User! Enter Valid User Credentials");
		}

	}

}]);

myRouting.controller('jobDetailsCtrl',['$routeParams','$scope',function($routeParams,$scope){
	console.log("test:"+$routeParams.JobSummary);

	$scope.JobSummary = $routeParams.JobSummary;

}]);

myRouting.controller('form_validationCtrl',['$scope',function ($scope) {
	var date=new Date();
	$scope.dateValue= date;
	$scope.form_submit=function (isValid) {
		if(isValid)
		{
			alert($scope.exp_name );
		}
		else
		{
			alert('Invalid details');
		}
	}
}]);
